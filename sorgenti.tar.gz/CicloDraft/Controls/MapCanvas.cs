using System.Globalization;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using CicloDraft.Geometry;
using CicloDraft.IO;
using CicloDraft.Model;

namespace CicloDraft.Controls;

/// <summary>Vista planimetrica: disegno e interazione col mouse.</summary>
public class MapCanvas : Control
{
    Editor? _ed;
    public Editor? Editor
    {
        get => _ed;
        set
        {
            if (_ed != null) _ed.Redraw -= OnRedraw;
            _ed = value;
            if (_ed != null) _ed.Redraw += OnRedraw;
            InvalidateBackground();
        }
    }

    // Vista: centro in metri locali, scala in pixel per metro
    double _cx, _cy, _s = 2;
    Point? _panLast;
    int _dragKey = -1; bool _keyMoved;
    bool _dragging;
    Point _lastScreen;

    public event Action<V2?>? PointerWorldMoved;
    public double Scale => _s;

    const double TolPx = 9;

    static readonly CultureInfo Ci = CultureInfo.GetCultureInfo("it-IT");
    static IBrush B(string hex, byte a = 255) { var c = Color.Parse(hex); return new ImmutableSolidColorBrush(Color.FromArgb(a, c.R, c.G, c.B)); }

    static readonly IBrush BgBrush = B("#F3F2EE");
    static readonly IBrush BuildingFill = B("#DADDE0");
    static readonly IBrush BuildingStroke = B("#959CA4");
    static readonly IBrush SidewalkFill = B("#E9E6DF");
    static readonly IBrush SidewalkStroke = B("#8E9BA6");
    static readonly IBrush OtherStroke = B("#BFC4C9");
    static readonly IBrush RoadEdge = B("#1E2833");
    static readonly IBrush Hover = B("#E7A500");
    static readonly IBrush Range = B("#FF7A00", 170);
    static readonly IBrush SelBrush = B("#1565C0");
    static readonly IBrush SnapBrush = B("#D81B60");
    static readonly IBrush TextBrush = B("#1E2833");
    static readonly IBrush LabelBg = B("#FFFFFF", 215);
    static readonly IBrush ErrBrush = B("#C62828");
    static readonly IBrush TreeBrush = B("#6C8E4B", 150);

    public static (IBrush fill, IBrush stroke) Colors(ElementType t, byte alpha = 215) => t switch
    {
        ElementType.Marciapiede => (B("#BBA781", alpha), B("#7D6C4C")),
        ElementType.Ciclabile => (B("#D6603F", alpha), B("#94381F")),
        ElementType.Carreggiata => (B("#6B7280", alpha), B("#3F4550")),
        ElementType.Corsia => (B("#93A3B8", alpha), B("#56667A")),
        ElementType.Parcheggio => (B("#6E9BC9", alpha), B("#3C6A98")),
        ElementType.Aiuola => (B("#86B068", alpha), B("#527B37")),
        ElementType.Separatore => (B("#F2C318", alpha), B("#A78300")),
        ElementType.CorsiaCiclabile => (B("#E8906F", alpha), B("#B0553A")),
        ElementType.CorsiaDoppia => (B("#7D8696", alpha), B("#4A5260")),
        _ => (B("#999999", alpha), B("#555555"))
    };

    public static string Hex(ElementType t) => t switch
    {
        ElementType.Marciapiede => "#BBA781", ElementType.Ciclabile => "#D6603F", ElementType.Carreggiata => "#6B7280",
        ElementType.Corsia => "#93A3B8", ElementType.Parcheggio => "#6E9BC9", ElementType.Aiuola => "#86B068",
        ElementType.Separatore => "#F2C318", ElementType.CorsiaCiclabile => "#E8906F", ElementType.CorsiaDoppia => "#7D8696", _ => "#999999"
    };

    StreamGeometry? _gBuild, _gSide, _gOther;
    bool _bgDirty = true;

    public MapCanvas()
    {
        Focusable = true;
        ClipToBounds = true;
    }

    public void InvalidateBackground() { _bgDirty = true; _bgBmpValid = false; InvalidateVisual(); }

    // ── sfondo (edifici, marciapiedi esistenti, livelli di sfondo, alberi) in un'immagine ──
    // Durante zoom e spostamenti si ridisegna l'immagine già pronta, scalata e spostata: è immediato anche con
    // migliaia di edifici. Quando la vista si ferma, l'immagine si rifà nitida alla nuova scala.
    static readonly bool NoBgCache = Environment.GetEnvironmentVariable("CICLODRAFT_NO_BG_CACHE") == "1";   // solo per le misure
    Avalonia.Media.Imaging.RenderTargetBitmap? _bgBmp;
    bool _bgBmpValid;
    double _bgS, _bgCx, _bgCy, _bgRot; Size _bgSize; Matrix _bgM = Matrix.Identity;
    Avalonia.Threading.DispatcherTimer? _bgTimer;

    void DrawBackground(DrawingContext ctx)
    {
        var ed = _ed;
        using (ctx.PushTransform(WorldToScreen))
        {
            if (_gOther != null) ctx.DrawGeometry(null, P(OtherStroke, 1), _gOther);
            if (_gSide != null) ctx.DrawGeometry(SidewalkFill, P(SidewalkStroke, 1, new DashStyle(new double[] { 4, 3 }, 0), PenLineCap.Flat), _gSide);
            if (_gBuild != null) ctx.DrawGeometry(BuildingFill, P(BuildingStroke, 1), _gBuild);
            if (ed?.Data is { } dd)
            {
                var treeBrush = TreeBrush;
                foreach (var l in dd.Layers)
                    if (l.Role != 0 && l.Visible && l.Points.Count > 0)
                        foreach (var tp in l.Points) ctx.DrawEllipse(treeBrush, null, new Point(tp.X, tp.Y), 1.6, 1.6);
            }
        }
    }

    void RebuildBackgroundBitmap()
    {
        if (Bounds.Width < 2 || Bounds.Height < 2) return;
        double scale = VisualRoot?.RenderScaling ?? 1;
        var px = new PixelSize(Math.Max(1, (int)Math.Ceiling(Bounds.Width * scale)), Math.Max(1, (int)Math.Ceiling(Bounds.Height * scale)));
        var bmp = new Avalonia.Media.Imaging.RenderTargetBitmap(px, new Vector(96 * scale, 96 * scale));
        using (var c = bmp.CreateDrawingContext()) DrawBackground(c);
        _bgBmp?.Dispose();
        _bgBmp = bmp; _bgS = _s; _bgCx = _cx; _bgCy = _cy; _bgRot = RotDeg; _bgM = WorldToScreen; _bgSize = Bounds.Size; _bgBmpValid = true;
    }

    void ScheduleBackgroundRefresh()
    {
        _bgTimer ??= new Avalonia.Threading.DispatcherTimer(TimeSpan.FromMilliseconds(140), Avalonia.Threading.DispatcherPriority.Background,
            (_, _) => { _bgTimer!.Stop(); RebuildBackgroundBitmap(); InvalidateVisual(); });
        _bgTimer.Stop(); _bgTimer.Start();
    }
    void OnRedraw() => InvalidateVisual();

    // ───────────── trasformazioni ─────────────

    // rotazione della vista (antioraria, in gradi): sta nel progetto, così si ritrova riaprendolo
    double RotDeg => _ed?.Project.ViewRotation ?? 0;
    double Cos => Math.Cos(RotDeg * Math.PI / 180);
    double Sin => Math.Sin(RotDeg * Math.PI / 180);
    Matrix WorldToScreen
    {
        get
        {
            double c = Cos * _s, s = Sin * _s;
            return new(c, -s, -s, -c, Bounds.Width / 2 - (c * _cx - s * _cy), Bounds.Height / 2 + (s * _cx + c * _cy));
        }
    }
    Point ToScreen(V2 w)
    {
        double dx = w.X - _cx, dy = w.Y - _cy, c = Cos, s = Sin;
        return new(Bounds.Width / 2 + (dx * c - dy * s) * _s, Bounds.Height / 2 - (dx * s + dy * c) * _s);
    }
    V2 ToWorld(Point p)
    {
        double rx = (p.X - Bounds.Width / 2) / _s, ry = (Bounds.Height / 2 - p.Y) / _s, c = Cos, s = Sin;
        return new(_cx + rx * c + ry * s, _cy - rx * s + ry * c);
    }
    /// <summary>Direzione nel mondo → direzione sullo schermo (unitaria se lo è v).</summary>
    Vector ScreenDir(V2 v) { double c = Cos, s = Sin; return new(v.X * c - v.Y * s, -(v.X * s + v.Y * c)); }

    /// <summary>Ruota la vista attorno al centro dello schermo (gradi, positivi = antiorario).</summary>
    public void Rotate(double deg)
    {
        if (_ed == null) return;
        double r = (RotDeg + deg) % 360; if (r > 180) r -= 360; if (r <= -180) r += 360;
        if (Math.Abs(r) < 1e-9) r = 0;
        _ed.Project.ViewRotation = r;
        _bgBmpValid = false;
        InvalidateVisual();
        ViewChanged?.Invoke();
    }
    public double Rotation => RotDeg;
    public event Action? ViewChanged;
    double Tol => TolPx / _s;

    public void ZoomTo(BBox b)
    {
        if (b.IsEmpty || Bounds.Width < 10) { _cx = 0; _cy = 0; _s = 2; InvalidateVisual(); return; }
        _cx = (b.MinX + b.MaxX) / 2; _cy = (b.MinY + b.MaxY) / 2;
        double w0 = Math.Max(b.MaxX - b.MinX, 1), h0 = Math.Max(b.MaxY - b.MinY, 1);
        // ingombro del riquadro ruotato
        double w = Math.Abs(w0 * Cos) + Math.Abs(h0 * Sin), h = Math.Abs(w0 * Sin) + Math.Abs(h0 * Cos);
        _s = Math.Min(Bounds.Width / w, Bounds.Height / h) * 0.9;
        InvalidateVisual();
    }

    // ───────────── disegno ─────────────

    void BuildBackground()
    {
        _bgDirty = false;
        _gBuild = _gSide = _gOther = null;
        var d = _ed?.Data;
        if (d == null) return;
        _gBuild = Geo(d.RingsWithRole(LayerRole.Muri).Where(x => x.layer.Visible).Select(x => x.ring), true);
        _gSide = Geo(d.RingsWithRole(LayerRole.Marciapiedi).Where(x => x.layer.Visible).Select(x => x.ring), true);
        _gOther = Geo(d.RingsWithRole(LayerRole.Sfondo, LayerRole.Edifici3D).Where(x => x.layer.Visible).Select(x => x.ring), false);
    }

    static StreamGeometry Geo(IEnumerable<Ring> rings, bool fill)
    {
        var g = new StreamGeometry();
        using var c = g.Open();
        c.SetFillRule(FillRule.EvenOdd);
        foreach (var r in rings)
        {
            if (r.Pts.Count < 2) continue;
            c.BeginFigure(new Point(r.Pts[0].X, r.Pts[0].Y), fill && r.Closed);
            for (int i = 1; i < r.Pts.Count; i++) c.LineTo(new Point(r.Pts[i].X, r.Pts[i].Y));
            c.EndFigure(r.Closed);
        }
        return g;
    }

    static StreamGeometry Line(IReadOnlyList<V2> pts, bool closed = false, bool filled = false)
    {
        var g = new StreamGeometry();
        using var c = g.Open();
        if (pts.Count == 0) return g;
        c.BeginFigure(new Point(pts[0].X, pts[0].Y), filled);
        for (int i = 1; i < pts.Count; i++) c.LineTo(new Point(pts[i].X, pts[i].Y));
        c.EndFigure(closed);
        return g;
    }

    Pen P(IBrush b, double px, IDashStyle? dash = null, PenLineCap cap = PenLineCap.Round) =>
        new(b, px / _s, dash, cap, PenLineJoin.Round);

    public override void Render(DrawingContext ctx)
    {
        var r = new Rect(Bounds.Size);
        ctx.FillRectangle(BgBrush, r);
        var ed = _ed;
        if (ed == null) return;
        if (_bgDirty) BuildBackground();

        // sfondo: immagine pronta se la vista è la stessa; altrimenti quella vecchia scalata e spostata, e se ne prepara una nuova
        if (NoBgCache) { DrawBackground(ctx); goto elements; }
        bool sameView = _bgBmpValid && _bgBmp != null && _bgS == _s && _bgCx == _cx && _bgCy == _cy && _bgRot == RotDeg && _bgSize == Bounds.Size;
        if (!_bgBmpValid || _bgBmp == null || _bgSize != Bounds.Size) { RebuildBackgroundBitmap(); sameView = _bgBmp != null; }
        if (_bgBmp != null)
        {
            if (sameView) ctx.DrawImage(_bgBmp, new Rect(_bgSize));
            else
            {
                // dall'immagine (schermo di allora) al mondo, e dal mondo allo schermo di adesso
                if (_bgM.TryInvert(out var inv))
                    using (ctx.PushTransform(inv * WorldToScreen))
                        ctx.DrawImage(_bgBmp, new Rect(_bgSize));
                ScheduleBackgroundRefresh();
            }
        }

        elements:
        using (ctx.PushTransform(WorldToScreen))
        {
            foreach (var e in ed.Project.Elements)
            {
                if (e.Polygon.Count < 3) continue;
                var (f, s) = Colors(e.Type);
                ctx.DrawGeometry(f, P(s, 1), Line(e.Polygon, true, true));
                foreach (var dl in e.DividerLines())
                {
                    if (dl.Count < 2) continue;
                    bool bk = e.Type is ElementType.Ciclabile or ElementType.CorsiaCiclabile;
                    // trattini in metri veri (i trattini di Avalonia sono multipli dello spessore della penna), almeno 3 px
                    double th = 0.9 / _s, dmin = 3 / 0.9;
                    var dash = e.DividerStyle == DividerStyle.Tratteggiata
                        ? new DashStyle(bk ? new[] { Math.Max(dmin, 1 / th), Math.Max(dmin, 1 / th) } : new[] { Math.Max(dmin, 4.5 / th), Math.Max(dmin, 7.5 / th) }, 0) : null;
                    if (e.DividerStyle == DividerStyle.DoppiaContinua)
                    {
                        ctx.DrawGeometry(null, P(Brushes.White, 0.8), Line(PL.OffsetProfile(dl, _ => 0.12, 1, Array.Empty<double>(), 1)));
                        ctx.DrawGeometry(null, P(Brushes.White, 0.8), Line(PL.OffsetProfile(dl, _ => 0.12, -1, Array.Empty<double>(), 1)));
                    }
                    else ctx.DrawGeometry(null, P(Brushes.White, 0.9, dash, PenLineCap.Flat), Line(dl));
                }
            }

            if (ed.Preview is { Error: null, Polygon.Count: >= 3 } pv)
            {
                var (f, s) = Colors(pv.Type, 150);
                ctx.DrawGeometry(f, P(s, 1.5, new DashStyle(new double[] { 3, 2 }, 0), PenLineCap.Flat), Line(pv.Polygon, true, true));
            }

            foreach (var e in ed.Project.Edges)
            {
                if (e.Points.Count < 2) continue;
                if (e.Owner == -1) ctx.DrawGeometry(null, P(RoadEdge, 2.6), Line(e.Points));          // bordo strada dei progetti precedenti
                else if (e.Owner == -2) ctx.DrawGeometry(null, P(SelBrush, 2.2), Line(e.Points));     // linea appena disegnata
                else if (ed.Project.Find(e.Owner) is { Centered: true })                                // interasse
                    ctx.DrawGeometry(null, P(RoadEdge, 1.1, new DashStyle(new double[] { 6, 4 }, 0), PenLineCap.Flat), Line(e.Points));
            }

            // Bordo sotto il puntatore
            if (ed.Mode is Mode.PickBase or Mode.PickOther || (ed.Mode == Mode.PickRange && ed.RangeFixed))
                if (ed.HoverEdge is { } he && ed.Project.GetEdge(he) is { } hl)
                    ctx.DrawGeometry(null, P(Hover, 5), Line(hl));

            // Tratto evidenziato
            if (ed.Mode is Mode.PickRange or Mode.SetWidth or Mode.PickOther && ed.DraftBase is { } db && !IsDrawnLine(ed, db) && ed.Project.GetEdge(db) is { } bl)
            {
                ctx.DrawGeometry(null, P(Hover, 2), Line(bl));
                var sub = PL.Sub(bl, ed.DraftStart, ed.DraftEnd);
                ctx.DrawGeometry(null, P(Range, ed.Mode == Mode.PickRange ? 8 : 3, null, PenLineCap.Flat), Line(sub));
                if (ed.Mode == Mode.PickOther && ed.DraftOther is { } dor && ed.Project.GetEdge(dor) is { } ol)
                    ctx.DrawGeometry(null, P(Hover, 4), Line(ol));
            }

            if (ed.Selected is { } sel && sel.Polygon.Count >= 3)
            {
                ctx.DrawGeometry(null, P(SelBrush, 2), Line(sel.Polygon, true));
                if (sel.Mode == ElementMode.Offset) ctx.DrawGeometry(null, P(SelBrush, 3.5), Line(sel.Outer));
            }

            if (ed.Mode == Mode.Trace && ed.TracePts.Count > 0)
            {
                var pts = new List<V2>(ed.TracePts);
                if (ed.Mouse is { } m) pts.Add(ed.Snap?.P ?? m);
                ctx.DrawGeometry(null, P(SelBrush, 2.6), Line(ed.TracePts));
                ctx.DrawGeometry(null, P(SelBrush, 1.4, new DashStyle(new double[] { 3, 3 }, 0), PenLineCap.Flat), Line(pts.Skip(pts.Count - 2).ToList()));
            }
        }

        // ── sovrapposizioni in coordinate schermo ──
        foreach (var e in ed.Project.Edges)
            if (e.Points.Count >= 2 && e.Owner == -1) DrawEdgeDecor(ctx, e);

        foreach (var e in ed.Project.Elements)
            if (e.Error == null && e.Polygon.Count >= 3) DrawElementLabel(ctx, e);
            else if (e.Error != null && ed.Project.GetEdge(e.Base) is { } bl2)
                Label(ctx, ToScreen(PL.PointAt(bl2, e.Start)), "⚠ " + e.Name + ": " + e.Error, ErrBrush);

        // elemento tracciato selezionato: verso della linea (frecce, inizio/fine) e lati destro/sinistro,
        // per «Aggiungi a destra / a sinistra»
        if (ed.Mode == Mode.Idle && ed.CanAddAlongside && ed.Selected is { } se && se.Guide.Count >= 2)
            DrawDirection(ctx, se);

        if (ed.Mode == Mode.EditLine && ed.EditEdge is { Anchors: { } an } eed)
        {
            if (eed.Points.Count >= 2) ctx.DrawGeometry(null, new Pen(SelBrush, 2.4), ScreenLine(eed.Points));
            if (ed.EditExtend != 0 && an.Count > 0 && ed.Mouse is { } mm)
            {
                var endA = ed.EditExtend > 0 ? an[^1] : an[0];
                ctx.DrawLine(new Pen(SelBrush, 1.4, new DashStyle(new double[] { 3, 3 }, 0)), ToScreen(new V2(endA.X, endA.Y)), ToScreen(ed.Snap?.P ?? mm));
            }
            for (int i = 0; i < an.Count; i++)
            {
                if (an[i].Auto) continue;
                var sp = ToScreen(new V2(an[i].X, an[i].Y));
                bool sel = i == ed.EditSel, end = i == 0 || i == an.Count - 1;
                IBrush fill = sel ? SelBrush : an[i].El >= 0 ? SnapBrush : Brushes.White;
                double rr = sel ? 6 : 4.5;
                if (end) ctx.DrawEllipse(fill, new Pen(SelBrush, 2), sp, rr + 1, rr + 1);
                else ctx.DrawRectangle(fill, new Pen(SelBrush, 1.6), new Rect(sp.X - rr, sp.Y - rr, 2 * rr, 2 * rr));
            }
            if (an.Count > 0)
            {
                Label(ctx, ToScreen(new V2(an[0].X, an[0].Y)) + new Vector(10, -22), "inizio", TextBrush);
                Label(ctx, ToScreen(new V2(an[^1].X, an[^1].Y)) + new Vector(10, 6), "fine", TextBrush);
            }
            if (ed.Snap is { } sn2)
            {
                var sp = ToScreen(sn2.P);
                var pen = new Pen(SnapBrush, 2);
                if (sn2.Vertex) ctx.DrawRectangle(null, pen, new Rect(sp.X - 6, sp.Y - 6, 12, 12));
                else { ctx.DrawLine(pen, sp + new Vector(-5, -5), sp + new Vector(5, 5)); ctx.DrawLine(pen, sp + new Vector(-5, 5), sp + new Vector(5, -5)); }
            }
        }

        if (ed.Mode == Mode.Trace)
        {
            foreach (var p in ed.TracePts)
            {
                var sp = ToScreen(p);
                ctx.DrawRectangle(Brushes.White, new Pen(SelBrush, 1.5), new Rect(sp.X - 3, sp.Y - 3, 6, 6));
            }
            if (ed.Snap is { } sn)
            {
                var sp = ToScreen(sn.P);
                var pen = new Pen(SnapBrush, 2);
                if (sn.Vertex) ctx.DrawRectangle(null, pen, new Rect(sp.X - 6, sp.Y - 6, 12, 12));
                else { ctx.DrawLine(pen, sp + new Vector(-5, -5), sp + new Vector(5, 5)); ctx.DrawLine(pen, sp + new Vector(-5, 5), sp + new Vector(5, -5)); }
            }
        }

        if (ed.Mode is Mode.PickRange or Mode.SetWidth or Mode.PickOther && ed.DraftBase is { } db2 && !IsDrawnLine(ed, db2) && ed.Project.GetEdge(db2) is { } bl3)
        {
            var a = ToScreen(PL.PointAt(bl3, ed.DraftStart));
            var b = ToScreen(PL.PointAt(bl3, ed.DraftEnd));
            Tick(ctx, a); Tick(ctx, b);
            Label(ctx, a + new Vector(8, -24), $"{ed.DraftStart:0.00} m", TextBrush);
            Label(ctx, b + new Vector(8, 6), $"{ed.DraftEnd:0.00} m  ·  tratto {Math.Abs(ed.DraftEnd - ed.DraftStart):0.00} m", TextBrush);
        }

        if (ed.Selected is { Mode: ElementMode.Offset, Error: null } s2)
        {
            for (int i = 0; i < s2.Profile.Count; i++)
            {
                var sp = ToScreen(ed.CpWorld(s2, s2.Profile[i]));
                bool act = i == ed.DragCp;
                ctx.DrawRectangle(act ? SelBrush : Brushes.White, new Pen(SelBrush, 2), new Rect(sp.X - 5, sp.Y - 5, 10, 10));
                if (act) Label(ctx, sp + new Vector(10, -10), $"{s2.Profile[i].W:0.00} m", SelBrush);
            }
        }

        DrawScaleBar(ctx);
    }

    StreamGeometry ScreenLine(IReadOnlyList<V2> pts)
    {
        var g = new StreamGeometry();
        using var c = g.Open();
        c.BeginFigure(ToScreen(pts[0]), false);
        for (int i = 1; i < pts.Count; i++) c.LineTo(ToScreen(pts[i]));
        c.EndFigure(false);
        return g;
    }

    /// <summary>Linea appena disegnata per il nuovo elemento: si usa per intero, niente tratto da evidenziare.</summary>
    static bool IsDrawnLine(Editor ed, EdgeRef r) => r.Kind == EdgeKind.Road && ed.Project.FindEdge(r.Id) is { Owner: -2 };

    void Tick(DrawingContext ctx, Point p) => ctx.DrawEllipse(Brushes.White, new Pen(Range, 3), p, 5, 5);

    void DrawEdgeDecor(DrawingContext ctx, RoadEdge e)
    {
        double L = PL.Length(e.Points);
        double step = 140 / _s;
        var pen = new Pen(RoadEdge, 1.6);
        for (double s = step / 2; s < L; s += step)
        {
            var p = ToScreen(PL.PointAt(e.Points, s));
            var t = PL.TangentAt(e.Points, s);
            var d = ScreenDir(t); var n = new Vector(-d.Y, d.X);
            ctx.DrawLine(pen, p, p - d * 7 + n * 4);
            ctx.DrawLine(pen, p, p - d * 7 - n * 4);
        }
        Label(ctx, ToScreen(e.Points[0]) + new Vector(6, -22), e.Name, RoadEdge, bold: true);
    }

    void DrawElementLabel(DrawingContext ctx, Element e)
    {
        double size = e.Mode == ElementMode.Polygon ? Math.Sqrt(e.Metrics.Area) : e.Metrics.WMean;
        double sizePx = size * _s;
        if (sizePx < 14 || (e.Mode != ElementMode.Polygon && e.Metrics.Length * _s < 80)) return;
        if (e.LabelCache == null || !ReferenceEquals(e.LabelKey, e.Polygon)) { e.LabelCache = DxfWriter.LabelPoint(e); e.LabelKey = e.Polygon; }
        var p = ToScreen(e.LabelCache.Value);
        var ft = Text($"{e.Name}  {e.Metrics.Area:0.0} m²", 11, TextBrush, true);
        var o = new Point(p.X - ft.Width / 2, p.Y - ft.Height / 2);
        ctx.FillRectangle(LabelBg, new Rect(o.X - 4, o.Y - 1, ft.Width + 8, ft.Height + 2), 3);
        ctx.DrawText(ft, o);
    }

    static FormattedText Text(string s, double size, IBrush brush, bool bold = false) =>
        new(s, Ci, FlowDirection.LeftToRight, new Typeface(FontFamily.Default, FontStyle.Normal, bold ? FontWeight.SemiBold : FontWeight.Normal), size, brush);

    void DrawDirection(DrawingContext ctx, Element e)
    {
        var g = e.Guide; double L = PL.Length(g);
        if (L < 1e-6) return;
        var pen = new Pen(SelBrush, 2, lineCap: PenLineCap.Round, lineJoin: PenLineJoin.Round);
        // frecce sulla linea, circa ogni 140 px
        double step = Math.Max(140 / _s, L / 40);
        for (double t = Math.Min(step / 2, L / 2); t < L; t += step)
        {
            var tg = PL.TangentAt(g, t);
            var c = ToScreen(PL.PointAt(g, t));
            var d = ScreenDir(tg); var n = new Vector(-d.Y, d.X);
            ctx.DrawLine(pen, c - d * 7 + n * 5, c);
            ctx.DrawLine(pen, c - d * 7 - n * 5, c);
        }
        Label(ctx, ToScreen(g[0]) + new Vector(8, -22), "inizio", TextBrush);
        Label(ctx, ToScreen(g[^1]) + new Vector(8, 6), "fine", TextBrush);
        // «sinistra» e «destra» a metà, appena fuori dall'elemento
        var tm = PL.TangentAt(g, L / 2); var pm = PL.PointAt(g, L / 2);
        var nl = tm.LeftNormal;
        double wl = e.Centered ? e.WidthAt(L / 2) / 2 : (e.Side > 0 ? e.WidthAt(L / 2) : 0);
        double wr = e.Centered ? e.WidthAt(L / 2) / 2 : (e.Side < 0 ? e.WidthAt(L / 2) : 0);
        foreach (var (txt, side, w) in new[] { ("sinistra", 1.0, wl), ("destra", -1.0, wr) })
        {
            var sp = ToScreen(pm + nl * (side * w));
            var off = ScreenDir(nl) * (side * 26);
            var ft = Text(txt, 11.5, TextBrush, false);
            Label(ctx, sp + off - new Vector(ft.Width / 2, ft.Height / 2), txt, TextBrush);
        }
    }

    static void Label(DrawingContext ctx, Point at, string s, IBrush brush, bool bold = false)
    {
        var ft = Text(s, 11.5, brush, bold);
        ctx.FillRectangle(LabelBg, new Rect(at.X - 3, at.Y - 1, ft.Width + 6, ft.Height + 2), 3);
        ctx.DrawText(ft, at);
    }

    void DrawScaleBar(DrawingContext ctx)
    {
        double target = 120 / _s;
        double mag = Math.Pow(10, Math.Floor(Math.Log10(target)));
        double len = new[] { 1, 2, 5, 10 }.Select(k => k * mag).Last(v => v <= target * 1.0001);
        double px = len * _s;
        var o = new Point(16, Bounds.Height - 22);
        var pen = new Pen(TextBrush, 2);
        ctx.DrawLine(pen, o, o + new Vector(px, 0));
        ctx.DrawLine(pen, o + new Vector(0, -5), o + new Vector(0, 3));
        ctx.DrawLine(pen, o + new Vector(px, -5), o + new Vector(px, 3));
        var ft = Text(len >= 1 ? $"{len:0} m" : $"{len:0.##} m", 11, TextBrush);
        ctx.DrawText(ft, o + new Vector(px + 6, -ft.Height / 2 - 1));
    }

    // ───────────── input ─────────────

    protected override void OnPointerPressed(PointerPressedEventArgs e)
    {
        base.OnPointerPressed(e);
        Focus();
        var ed = _ed; if (ed == null) return;
        var pt = e.GetCurrentPoint(this);
        var sp = pt.Position; var w = ToWorld(sp);
        _lastScreen = sp;

        if (pt.Properties.IsMiddleButtonPressed || pt.Properties.IsRightButtonPressed)
        {
            _panLast = sp; e.Pointer.Capture(this); return;
        }
        if (!pt.Properties.IsLeftButtonPressed) return;

        switch (ed.Mode)
        {
            case Mode.Trace:
                if (e.ClickCount >= 2) ed.TraceFinish();
                else ed.TraceClick(w, Tol);
                break;
            case Mode.PickBase:
            case Mode.PickRange:
            case Mode.PickOther:
                ed.ClickPick(w, Tol);
                if (ed.Mode == Mode.PickBase) { _panLast = sp; e.Pointer.Capture(this); }
                break;
            case Mode.SetWidth:
                _panLast = sp; e.Pointer.Capture(this);
                break;
            case Mode.EditLine:
            {
                int kp = ed.HitKeyPoint(w, Tol);
                if (kp >= 0)
                {
                    ed.SelectKeyPoint(kp);
                    _dragKey = kp; e.Pointer.Capture(this);
                    return;
                }
                if (ed.EditExtend != 0) { ed.ExtendClick(w, Tol); return; }
                if (e.ClickCount >= 2 && ed.InsertKeyPoint(w, Tol)) { _dragKey = ed.EditSel; e.Pointer.Capture(this); return; }
                ed.SelectKeyPoint(-1);
                _panLast = sp; e.Pointer.Capture(this);
                break;
            }
            case Mode.Idle:
                int cp = ed.HitCp(w, Tol);
                if (cp >= 0)
                {
                    if (e.KeyModifiers.HasFlag(KeyModifiers.Control)) { ed.RemoveCp(cp); return; }
                    ed.DragCp = cp; _dragging = true; e.Pointer.Capture(this); ed.NotifyRedraw();
                    return;
                }
                if (e.ClickCount >= 2 && ed.TryAddCp(w, Tol)) { _dragging = true; e.Pointer.Capture(this); return; }
                var before = ed.Selected;
                ed.SelectAt(w);
                if (ed.Selected == null) { _panLast = sp; e.Pointer.Capture(this); }
                break;
        }
    }

    protected override void OnPointerMoved(PointerEventArgs e)
    {
        base.OnPointerMoved(e);
        var ed = _ed; if (ed == null) return;
        var sp = e.GetPosition(this);
        var w = ToWorld(sp);
        ed.Mouse = w;
        PointerWorldMoved?.Invoke(w);

        if (_panLast is { } last)
        {
            var d = sp - last;
            double rx = d.X / _s, ry = -d.Y / _s, c = Cos, sn = Sin;
            _cx -= rx * c + ry * sn; _cy -= -rx * sn + ry * c;
            _panLast = sp;
            InvalidateVisual();
            return;
        }
        if (_dragging) { ed.MoveCp(w); return; }
        if (_dragKey >= 0) { _keyMoved = true; ed.MoveKeyPoint(_dragKey, w, Tol, false); InvalidateVisual(); return; }

        switch (ed.Mode)
        {
            case Mode.Trace:
                ed.Snap = ed.FindSnap(w, Tol);
                break;
            case Mode.EditLine:
                ed.Snap = ed.EditExtend != 0 ? ed.FindSnap(w, Tol) : null;
                Cursor = ed.HitKeyPoint(w, Tol) >= 0 ? new Cursor(StandardCursorType.SizeAll) : Cursor.Default;
                break;
            case Mode.PickBase:
            case Mode.PickOther:
                ed.HoverEdge = ed.NearestEdge(w, Tol, ed.Mode == Mode.PickOther ? ed.DraftBase : null)?.r;
                break;
            case Mode.PickRange:
                if (!ed.RangeFixed) ed.HoverRange(w);
                else ed.HoverEdge = ed.NearestEdge(w, Tol)?.r;
                break;
            case Mode.Idle:
                Cursor = ed.HitCp(w, Tol) >= 0 ? new Cursor(StandardCursorType.SizeAll) : Cursor.Default;
                break;
        }
        InvalidateVisual();
    }

    protected override void OnPointerReleased(PointerReleasedEventArgs e)
    {
        base.OnPointerReleased(e);
        _panLast = null;
        if (_dragging && _ed != null) { _ed.DragCp = -1; _ed.NotifyAll(); }
        _dragging = false;
        if (_dragKey >= 0 && _ed != null && _keyMoved) _ed.MoveKeyPoint(_dragKey, ToWorld(e.GetPosition(this)), Tol, true);
        _dragKey = -1; _keyMoved = false;
        e.Pointer.Capture(null);
    }

    protected override void OnPointerExited(PointerEventArgs e)
    {
        base.OnPointerExited(e);
        if (_ed != null) { _ed.Mouse = null; _ed.Snap = null; }
        PointerWorldMoved?.Invoke(null);
        InvalidateVisual();
    }

    protected override void OnPointerWheelChanged(PointerWheelEventArgs e)
    {
        base.OnPointerWheelChanged(e);
        var sp = e.GetPosition(this);
        var before = ToWorld(sp);
        _s = Math.Clamp(_s * Math.Pow(1.2, e.Delta.Y), 0.01, 2000);
        var after = ToWorld(sp);
        _cx += before.X - after.X; _cy += before.Y - after.Y;
        InvalidateVisual();
        e.Handled = true;
    }
}
