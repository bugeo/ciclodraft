using System.Text.Json;
using System.Text.Json.Serialization;
using CicloDraft.Geometry;
using CicloDraft.Model;

namespace CicloDraft.IO;

/// <summary>Salvataggio del progetto (.ciclo, JSON). Le coordinate sono assolute (CRS del GeoPackage).</summary>
public static class ProjectFile
{
    public class Dto
    {
        public int Version { get; set; } = 1;
        public string? GpkgPath { get; set; }
        public double[]? Origin { get; set; }
        public Dictionary<string, int> LayerRoles { get; set; } = new();
        /// <summary>Livelli nascosti alla vista.</summary>
        public List<string> HiddenLayers { get; set; } = new();
        public List<EdgeDto> Edges { get; set; } = new();
        public List<ElementDto> Elements { get; set; } = new();
        public int NextId { get; set; }
        public double ViewRotation { get; set; }
    }
    public class EdgeDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public List<double[]> Points { get; set; } = new();
        /// <summary>Punti agganciati agli elementi (coordinate assolute).</summary>
        public List<EdgeAnchor>? Anchors { get; set; }
        public int Owner { get; set; } = -1;
    }
    public class ElementDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public ElementType Type { get; set; }
        public ElementMode Mode { get; set; }
        public EdgeKind BaseKind { get; set; }
        public int BaseId { get; set; }
        public double Start { get; set; }
        public double End { get; set; }
        public int Side { get; set; }
        public double Width { get; set; }
        public double Smooth { get; set; } = 1.0;
        public bool ToEnd { get; set; }
        public List<double[]> Profile { get; set; } = new();
        public EdgeKind? OtherKind { get; set; }
        public int? OtherId { get; set; }
        public bool Centered { get; set; }
        public int Dividers { get; set; } = -1;
        public DividerStyle DividerStyle { get; set; }
    }

    static readonly JsonSerializerOptions Opts = new()
    {
        WriteIndented = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public static void Save(string path, Project p, GpkgData? data)
    {
        V2 o = data?.Origin ?? new V2(0, 0);
        var dto = new Dto
        {
            GpkgPath = data?.Path,
            Origin = new[] { o.X, o.Y },
            NextId = p.NextId,
            ViewRotation = p.ViewRotation,
            LayerRoles = data?.Layers.ToDictionary(l => l.Name, l => l.Role) ?? new(),
            HiddenLayers = data?.Layers.Where(l => !l.Visible).Select(l => l.Name).ToList() ?? new(),
            Edges = p.Edges.Select(e => new EdgeDto
            {
                Id = e.Id, Name = e.Name,
                Points = e.Points.Select(v => new[] { v.X + o.X, v.Y + o.Y }).ToList(),
                Anchors = e.Anchors?.Select(a => new EdgeAnchor { X = a.X + o.X, Y = a.Y + o.Y, El = a.El, S = a.S, Follow = a.Follow, Sd = a.Sd, Auto = a.Auto }).ToList(),
                Owner = e.Owner
            }).ToList(),
            Elements = p.Elements.Select(e => new ElementDto
            {
                Id = e.Id, Name = e.Name, Type = e.Type, Mode = e.Mode,
                BaseKind = e.Base.Kind, BaseId = e.Base.Id, Start = e.Start, End = e.End,
                Side = e.Side, Width = e.Width, Smooth = e.Smooth, ToEnd = e.ToEnd,
                Profile = e.Profile.Select(w => new[] { w.T, w.W }).ToList(),
                OtherKind = e.Other?.Kind, OtherId = e.Other?.Id, Centered = e.Centered,
                Dividers = e.Dividers, DividerStyle = e.DividerStyle
            }).ToList()
        };
        File.WriteAllText(path, JsonSerializer.Serialize(dto, Opts));
    }

    public static Dto Read(string path) =>
        JsonSerializer.Deserialize<Dto>(File.ReadAllText(path), Opts) ?? throw new InvalidDataException("File di progetto non valido");

    /// <summary>Riempie il progetto dal DTO, convertendo in coordinate locali rispetto a origin.</summary>
    public static Project ToProject(Dto dto, V2 origin)
    {
        var p = new Project { NextId = Math.Max(1, dto.NextId), ViewRotation = dto.ViewRotation };
        foreach (var e in dto.Edges)
        {
            var target = p.Edges.FirstOrDefault(x => x.Id == e.Id);
            if (target == null) { target = new RoadEdge { Id = e.Id }; p.Edges.Add(target); }
            target.Name = e.Name;
            target.Points = e.Points.Select(a => new V2(a[0] - origin.X, a[1] - origin.Y)).ToList();
            target.Anchors = e.Anchors?.Select(a => new EdgeAnchor { X = a.X - origin.X, Y = a.Y - origin.Y, El = a.El, S = a.S, Follow = a.Follow, Sd = a.Sd == 0 ? 1 : a.Sd, Auto = a.Auto }).ToList();
            target.Owner = e.Owner;
        }
        foreach (var d in dto.Elements)
        {
            p.Elements.Add(new Element
            {
                Id = d.Id, Name = d.Name, Type = d.Type, Mode = d.Mode,
                Base = new EdgeRef(d.BaseKind, d.BaseId), Start = d.Start, End = d.End,
                Side = d.Side == 0 ? 1 : d.Side, Width = d.Width, Smooth = d.Smooth, ToEnd = d.ToEnd,
                Profile = d.Profile.Select(a => new WidthPoint { T = a[0], W = a[1] }).ToList(),
                Other = d.OtherKind is { } k && d.OtherId is { } id ? new EdgeRef(k, id) : null,
                Centered = d.Centered, Dividers = d.Dividers, DividerStyle = d.DividerStyle
            });
            p.NextId = Math.Max(p.NextId, d.Id + 1);
        }
        p.Regenerate();
        return p;
    }
}
